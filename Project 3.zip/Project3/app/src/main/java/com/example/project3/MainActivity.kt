package com.example.project3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.project3.ui.theme.Project3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Project3Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                )
                // Check if the user is logged in.
                FirebaseUser user = FirebaseAuth . getInstance ().getCurrentUser();
                if (user != null) {
                    // User is signed in.
                    // Proceed to the main part of your app.
                } else {
                    // User is not signed in, prompt for login or registration.
                }
                public class DatabaseHelper extends SQLiteOpenHelper {
                private static final String DATABASE_NAME = "YourDatabaseName.db";
                private static final int DATABASE_VERSION = 1;

                public DatabaseHelper (Context context) {
                    super(context, DATABASE_NAME, null, DATABASE_VERSION);
                }

                @Override
                public void onCreate(SQLiteDatabase db) {
                    // Create your tables here.
                }

                @Override
                public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
                    // Handle database upgrades if needed.
                }
            }
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    // Permission not granted, request it.
                    ActivityCompat.requestPermissions(
                        this,
                        new String []{ Manifest.permission.SEND_SMS },
                        SMS_PERMISSION_REQUEST_CODE
                    );
                }
                SmsManager smsManager = SmsManager . getDefault ();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Project3Theme {
        Greeting("Android")
    }
}